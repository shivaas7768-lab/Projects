package year;

public class Employee {
    private int    empId;
    private String name;
    private String email;
    private String phone;
    private String role;
    private int    deptId;
    private String deptName;
    private String username;
    private String password;
 
    public Employee() {}
 
    public Employee(int empId, String name, String email, String phone,
                    String role, int deptId, String deptName) {
        this.empId    = empId;
        this.name     = name;
        this.email    = email;
        this.phone    = phone;
        this.role     = role;
        this.deptId   = deptId;
        this.deptName = deptName;
    }
 
    // Getters and Setters
    public int    getEmpId()    { return empId; }
    public void   setEmpId(int empId) { this.empId = empId; }
    public String getName()     { return name; }
    public void   setName(String name) { this.name = name; }
    public String getEmail()    { return email; }
    public void   setEmail(String email) { this.email = email; }
    public String getPhone()    { return phone; }
    public void   setPhone(String phone) { this.phone = phone; }
    public String getRole()     { return role; }
    public void   setRole(String role) { this.role = role; }
    public int    getDeptId()   { return deptId; }
    public void   setDeptId(int deptId) { this.deptId = deptId; }
    public String getDeptName() { return deptName; }
    public void   setDeptName(String deptName) { this.deptName = deptName; }
    public String getUsername() { return username; }
    public void   setUsername(String username) { this.username = username; }
    public String getPassword() { return password; }
    public void   setPassword(String password) { this.password = password; }
 
    @Override
    public String toString() {
        return String.format("[%d] %-20s | %-12s | %-15s | Dept: %s",
                empId, name, role, email, deptName != null ? deptName : "N/A");
    }


}
