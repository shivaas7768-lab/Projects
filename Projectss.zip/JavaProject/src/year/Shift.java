package year;
import java.sql.Date;
import java.sql.Time;
public class Shift {
    private int    shiftId;
    private int    empId;
    private String empName;
    private Date   shiftDate;
    private Time   startTime;
    private Time   endTime;
    private String shiftType;
    private String status;
 
    public Shift() {}
 
    public Shift(int empId, Date shiftDate, Time startTime, Time endTime,
                 String shiftType) {
        this.empId     = empId;
        this.shiftDate = shiftDate;
        this.startTime = startTime;
        this.endTime   = endTime;
        this.shiftType = shiftType;
        this.status    = "SCHEDULED";
    }
 
    public int    getShiftId()  { return shiftId; }
    public void   setShiftId(int shiftId) { this.shiftId = shiftId; }
    public int    getEmpId()    { return empId; }
    public void   setEmpId(int empId) { this.empId = empId; }
    public String getEmpName()  { return empName; }
    public void   setEmpName(String empName) { this.empName = empName; }
    public Date   getShiftDate(){ return shiftDate; }
    public void   setShiftDate(Date shiftDate) { this.shiftDate = shiftDate; }
    public Time   getStartTime(){ return startTime; }
    public void   setStartTime(Time startTime) { this.startTime = startTime; }
    public Time   getEndTime()  { return endTime; }
    public void   setEndTime(Time endTime) { this.endTime = endTime; }
    public String getShiftType(){ return shiftType; }
    public void   setShiftType(String shiftType) { this.shiftType = shiftType; }
    public String getStatus()   { return status; }
    public void   setStatus(String status) { this.status = status; }
 
    @Override
    public String toString() {
        return String.format("[%d] Employee: %-15s | Date: %s | %s - %s | %-10s | Status: %s",
                shiftId, empName != null ? empName : "ID:" + empId,
                shiftDate, startTime, endTime, shiftType, status);
    }
}
 
 

