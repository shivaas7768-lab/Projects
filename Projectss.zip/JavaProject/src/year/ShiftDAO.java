package year;
import year.Shift;
import year.DBConnection;
 import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ShiftDAO {

    // ─── CREATE ──────────────────────────────────────────────────────────────
    public boolean addShift(Shift shift) {
        String sql = "INSERT INTO shifts (emp_id, shift_date, start_time, end_time, shift_type) " +
                     "VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1,    shift.getEmpId());
            ps.setDate(2,   shift.getShiftDate());
            ps.setTime(3,   shift.getStartTime());
            ps.setTime(4,   shift.getEndTime());
            ps.setString(5, shift.getShiftType());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("addShift error: " + e.getMessage());
            return false;
        }
    }
 
    // ─── READ ALL ─────────────────────────────────────────────────────────────
    public List<Shift> getAllShifts() {
        List<Shift> list = new ArrayList<>();
        // JOIN QUERY 2: shifts with employee name and department
        String sql = "SELECT s.shift_id, s.emp_id, e.name AS emp_name, " +
                     "       s.shift_date, s.start_time, s.end_time, s.shift_type, s.status " +
                     "FROM shifts s " +
                     "JOIN employees e ON s.emp_id = e.emp_id " +
                     "ORDER BY s.shift_date, s.start_time";
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                Shift s = new Shift();
                s.setShiftId(rs.getInt("shift_id"));
                s.setEmpId(rs.getInt("emp_id"));
                s.setEmpName(rs.getString("emp_name"));
                s.setShiftDate(rs.getDate("shift_date"));
                s.setStartTime(rs.getTime("start_time"));
                s.setEndTime(rs.getTime("end_time"));
                s.setShiftType(rs.getString("shift_type"));
                s.setStatus(rs.getString("status"));
                list.add(s);
            }
        } catch (SQLException e) {
            System.err.println("getAllShifts error: " + e.getMessage());
        }
        return list;
    }
 
    // ─── READ BY EMPLOYEE ─────────────────────────────────────────────────────
    public List<Shift> getShiftsByEmployee(int empId) {
        List<Shift> list = new ArrayList<>();
        String sql = "SELECT s.shift_id, s.emp_id, e.name AS emp_name, " +
                     "       s.shift_date, s.start_time, s.end_time, s.shift_type, s.status " +
                     "FROM shifts s JOIN employees e ON s.emp_id = e.emp_id " +
                     "WHERE s.emp_id = ? ORDER BY s.shift_date";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, empId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Shift s = new Shift();
                s.setShiftId(rs.getInt("shift_id"));
                s.setEmpId(rs.getInt("emp_id"));
                s.setEmpName(rs.getString("emp_name"));
                s.setShiftDate(rs.getDate("shift_date"));
                s.setStartTime(rs.getTime("start_time"));
                s.setEndTime(rs.getTime("end_time"));
                s.setShiftType(rs.getString("shift_type"));
                s.setStatus(rs.getString("status"));
                list.add(s);
            }
        } catch (SQLException e) {
            System.err.println("getShiftsByEmployee error: " + e.getMessage());
        }
        return list;
    }
 
    // ─── UPDATE STATUS ────────────────────────────────────────────────────────
    public boolean updateShiftStatus(int shiftId, String status) {
        String sql = "UPDATE shifts SET status = ? WHERE shift_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setInt(2,    shiftId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("updateShiftStatus error: " + e.getMessage());
            return false;
        }
    }
 
    // ─── DELETE ───────────────────────────────────────────────────────────────
    public boolean deleteShift(int shiftId) {
        String sql = "DELETE FROM shifts WHERE shift_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, shiftId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("deleteShift error: " + e.getMessage());
            return false;
        }
    }


}
