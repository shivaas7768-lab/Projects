package year;
import year.DBConnection;
 
import java.sql.Date;
import java.sql.Time;
import java.util.List;
import java.util.Scanner;

public class MainApp {
    private static final Scanner sc     = new Scanner(System.in);
    private static final EmployeeDAO    empDAO  = new EmployeeDAO();
    private static final ShiftDAO       shiftDAO= new ShiftDAO();
    private static final LeaveRequestDAO leaveDAO= new LeaveRequestDAO();
    private static final AttendanceDAO  attDAO  = new AttendanceDAO();
 
    private static Employee currentUser = null;
 
    public static void main(String[] args) {
        banner();
        loginFlow();
        if (currentUser == null) {
            System.out.println("Login failed. Exiting.");
            return;
        }
        if ("MANAGER".equals(currentUser.getRole())) {
            managerMenu();
        } else {
            employeeMenu();
        }
        DBConnection.closeConnection();
        System.out.println("\nGoodbye!");
    }
 
    // ─── BANNER ───────────────────────────────────────────────────────────────
    static void banner() {
        System.out.println("╔══════════════════════════════════════════════════════╗");
        System.out.println("║     EMPLOYEE SHIFT SCHEDULING SYSTEM  v1.0           ║");
        System.out.println("║         Java + MySQL  |  DAO Pattern                 ║");
        System.out.println("╚══════════════════════════════════════════════════════╝");
    }
 
    // ─── LOGIN ────────────────────────────────────────────────────────────────
    static void loginFlow() {
        System.out.print("\nUsername: ");
        String user = sc.nextLine().trim();
        System.out.print("Password: ");
        String pass = sc.nextLine().trim();
        currentUser = empDAO.login(user, pass);
        if (currentUser != null) {
            System.out.println("\n✔  Welcome, " + currentUser.getName() +
                               "  [" + currentUser.getRole() + " | " + currentUser.getDeptName() + "]");
        }
    }
 
    // ════════════════════════════════════════════════════════════════════════
    //  MANAGER MENU
    // ════════════════════════════════════════════════════════════════════════
    static void managerMenu() {
        while (true) {
            System.out.println("\n┌─── MANAGER MENU ──────────────────────┐");
            System.out.println("│  1. Employee Management                 │");
            System.out.println("│  2. Shift Management                    │");
            System.out.println("│  3. Leave Request Management            │");
            System.out.println("│  4. Attendance Report                   │");
            System.out.println("│  0. Logout                              │");
            System.out.println("└─────────────────────────────────────────┘");
            System.out.print("Choice: ");
            String ch = sc.nextLine().trim();
            switch (ch) {
                case "1": employeeManagement(); break;
                case "2": shiftManagement();    break;
                case "3": leaveManagement();    break;
                case "4": attendanceReport();   break;
                case "0": return;
                default:  System.out.println("Invalid option.");
            }
        }
    }
 
    // ─── EMPLOYEE MANAGEMENT ─────────────────────────────────────────────────
    static void employeeManagement() {
        System.out.println("\n── EMPLOYEE MANAGEMENT ──");
        System.out.println("1. View All  2. Add  3. Update  4. Delete");
        System.out.print("Choice: ");
        String ch = sc.nextLine().trim();
        switch (ch) {
            case "1": viewAllEmployees(); break;
            case "2": addEmployee();      break;
            case "3": updateEmployee();   break;
            case "4": deleteEmployee();   break;
        }
    }
 
    static void viewAllEmployees() {
        List<Employee> list = empDAO.getAllEmployees();
        System.out.println("\n── All Employees ──────────────────────────────────────────────────────");
        System.out.printf("%-5s %-22s %-12s %-25s %-15s%n", "ID", "Name", "Role", "Email", "Department");
        System.out.println("-".repeat(85));
        list.forEach(e -> System.out.printf("%-5d %-22s %-12s %-25s %-15s%n",
                e.getEmpId(), e.getName(), e.getRole(), e.getEmail(), e.getDeptName()));
    }
 
    static void addEmployee() {
        System.out.println("\n── Add New Employee ──");
        Employee emp = new Employee();
        System.out.print("Name     : "); emp.setName(sc.nextLine());
        System.out.print("Email    : "); emp.setEmail(sc.nextLine());
        System.out.print("Phone    : "); emp.setPhone(sc.nextLine());
        System.out.print("Role (MANAGER/EMPLOYEE): "); emp.setRole(sc.nextLine().toUpperCase());
        System.out.print("Dept ID  : "); emp.setDeptId(Integer.parseInt(sc.nextLine()));
        System.out.print("Username : "); emp.setUsername(sc.nextLine());
        System.out.print("Password : "); emp.setPassword(sc.nextLine());
        System.out.println(empDAO.addEmployee(emp) ? "✔ Employee added." : "✘ Failed.");
    }
 
    static void updateEmployee() {
        System.out.print("Enter Employee ID to update: ");
        int id = Integer.parseInt(sc.nextLine());
        Employee emp = empDAO.getEmployeeById(id);
        if (emp == null) { System.out.println("Not found."); return; }
        System.out.println("Current: " + emp);
        System.out.print("New Name  (blank=keep): "); String n = sc.nextLine();
        System.out.print("New Email (blank=keep): "); String e = sc.nextLine();
        System.out.print("New Phone (blank=keep): "); String p = sc.nextLine();
        if (!n.isEmpty()) emp.setName(n);
        if (!e.isEmpty()) emp.setEmail(e);
        if (!p.isEmpty()) emp.setPhone(p);
        System.out.println(empDAO.updateEmployee(emp) ? "✔ Updated." : "✘ Failed.");
    }
 
    static void deleteEmployee() {
        System.out.print("Enter Employee ID to delete: ");
        int id = Integer.parseInt(sc.nextLine());
        System.out.println(empDAO.deleteEmployee(id) ? "✔ Deleted." : "✘ Failed.");
    }
 
    // ─── SHIFT MANAGEMENT ────────────────────────────────────────────────────
    static void shiftManagement() {
        System.out.println("\n── SHIFT MANAGEMENT ──");
        System.out.println("1. View All Shifts  2. Assign Shift  3. Update Status  4. Delete Shift");
        System.out.print("Choice: ");
        String ch = sc.nextLine().trim();
        switch (ch) {
            case "1": viewAllShifts();    break;
            case "2": assignShift();      break;
            case "3": updateShiftStatus();break;
            case "4": deleteShift();      break;
        }
    }
 
    static void viewAllShifts() {
        List<Shift> list = shiftDAO.getAllShifts();
        System.out.println("\n── All Shifts ─────────────────────────────────────────────────────────");
        System.out.printf("%-5s %-20s %-12s %-10s %-10s %-12s %-12s%n",
                "ID", "Employee", "Date", "Start", "End", "Type", "Status");
        System.out.println("-".repeat(90));
        list.forEach(s -> System.out.printf("%-5d %-20s %-12s %-10s %-10s %-12s %-12s%n",
                s.getShiftId(), s.getEmpName(), s.getShiftDate(),
                s.getStartTime(), s.getEndTime(), s.getShiftType(), s.getStatus()));
    }
 
    static void assignShift() {
        System.out.println("\n── Assign New Shift ──");
        System.out.print("Employee ID  : "); int empId = Integer.parseInt(sc.nextLine());
        System.out.print("Date (YYYY-MM-DD): "); Date date = Date.valueOf(sc.nextLine());
        System.out.print("Start time (HH:MM:SS): "); Time start = Time.valueOf(sc.nextLine());
        System.out.print("End time   (HH:MM:SS): "); Time end   = Time.valueOf(sc.nextLine());
        System.out.print("Type (MORNING/AFTERNOON/NIGHT): "); String type = sc.nextLine().toUpperCase();
        Shift shift = new Shift(empId, date, start, end, type);
        System.out.println(shiftDAO.addShift(shift) ? "✔ Shift assigned." : "✘ Failed.");
    }
 
    static void updateShiftStatus() {
        System.out.print("Shift ID: "); int id = Integer.parseInt(sc.nextLine());
        System.out.print("New Status (SCHEDULED/COMPLETED/CANCELLED): ");
        String status = sc.nextLine().toUpperCase();
        System.out.println(shiftDAO.updateShiftStatus(id, status) ? "✔ Updated." : "✘ Failed.");
    }
 
    static void deleteShift() {
        System.out.print("Shift ID to delete: "); int id = Integer.parseInt(sc.nextLine());
        System.out.println(shiftDAO.deleteShift(id) ? "✔ Deleted." : "✘ Failed.");
    }
 
    // ─── LEAVE MANAGEMENT ────────────────────────────────────────────────────
    static void leaveManagement() {
        System.out.println("\n── LEAVE REQUEST MANAGEMENT ──");
        System.out.println("1. View All  2. Approve  3. Reject  4. Delete");
        System.out.print("Choice: ");
        String ch = sc.nextLine().trim();
        switch (ch) {
            case "1": viewAllLeave(); break;
            case "2": System.out.print("Leave ID: "); leaveDAO.updateLeaveStatus(Integer.parseInt(sc.nextLine()),"APPROVED"); System.out.println("✔ Approved."); break;
            case "3": System.out.print("Leave ID: "); leaveDAO.updateLeaveStatus(Integer.parseInt(sc.nextLine()),"REJECTED"); System.out.println("✔ Rejected."); break;
            case "4": System.out.print("Leave ID: "); leaveDAO.deleteLeaveRequest(Integer.parseInt(sc.nextLine())); System.out.println("✔ Deleted."); break;
        }
    }
 
    static void viewAllLeave() {
        List<LeaveRequest> list = leaveDAO.getAllLeaveRequests();
        System.out.println("\n── Leave Requests ─────────────────────────────────────────────────────");
        System.out.printf("%-5s %-20s %-12s %-12s %-25s %-10s%n",
                "ID", "Employee", "From", "To", "Reason", "Status");
        System.out.println("-".repeat(90));
        list.forEach(lr -> System.out.printf("%-5d %-20s %-12s %-12s %-25s %-10s%n",
                lr.getLeaveId(), lr.getEmpName(), lr.getStartDate(),
                lr.getEndDate(), lr.getReason(), lr.getStatus()));
    }
 
    // ─── ATTENDANCE REPORT ────────────────────────────────────────────────────
    static void attendanceReport() {
        System.out.println("\n── ATTENDANCE REPORT ──");
        attDAO.getAttendanceReport().forEach(System.out::println);
    }
 
    // ════════════════════════════════════════════════════════════════════════
    //  EMPLOYEE MENU
    // ════════════════════════════════════════════════════════════════════════
    static void employeeMenu() {
        while (true) {
            System.out.println("\n┌─── EMPLOYEE MENU ─────────────────────┐");
            System.out.println("│  1. View My Shifts                      │");
            System.out.println("│  2. Apply for Leave                     │");
            System.out.println("│  3. View My Leave Requests              │");
            System.out.println("│  4. Mark Attendance (Check In)          │");
            System.out.println("│  5. Mark Attendance (Check Out)         │");
            System.out.println("│  0. Logout                              │");
            System.out.println("└─────────────────────────────────────────┘");
            System.out.print("Choice: ");
            String ch = sc.nextLine().trim();
            switch (ch) {
                case "1": viewMyShifts();    break;
                case "2": applyLeave();      break;
                case "3": viewMyLeave();     break;
                case "4": checkIn();         break;
                case "5": checkOut();        break;
                case "0": return;
                default:  System.out.println("Invalid.");
            }
        }
    }
 
    static void viewMyShifts() {
        List<Shift> list = shiftDAO.getShiftsByEmployee(currentUser.getEmpId());
        System.out.println("\n── My Shifts ──────────────────────────────────────────────────────");
        System.out.printf("%-5s %-12s %-10s %-10s %-12s %-12s%n",
                "ID", "Date", "Start", "End", "Type", "Status");
        System.out.println("-".repeat(70));
        list.forEach(s -> System.out.printf("%-5d %-12s %-10s %-10s %-12s %-12s%n",
                s.getShiftId(), s.getShiftDate(), s.getStartTime(),
                s.getEndTime(), s.getShiftType(), s.getStatus()));
    }
 
    static void applyLeave() {
        System.out.println("\n── Apply for Leave ──");
        System.out.print("Start Date (YYYY-MM-DD): "); Date start = Date.valueOf(sc.nextLine());
        System.out.print("End Date   (YYYY-MM-DD): "); Date end   = Date.valueOf(sc.nextLine());
        System.out.print("Reason                 : "); String reason = sc.nextLine();
        LeaveRequest lr = new LeaveRequest(currentUser.getEmpId(), start, end, reason);
        System.out.println(leaveDAO.applyLeave(lr) ? "✔ Leave request submitted." : "✘ Failed.");
    }
 
    static void viewMyLeave() {
        List<LeaveRequest> list = leaveDAO.getLeaveByEmployee(currentUser.getEmpId());
        System.out.println("\n── My Leave Requests ──────────────────────────────────────────────");
        list.forEach(System.out::println);
    }
 
    static void checkIn() {
        System.out.print("Shift ID for check-in: "); int shiftId = Integer.parseInt(sc.nextLine());
        System.out.println(attDAO.markAttendance(currentUser.getEmpId(), shiftId) ?
                "✔ Checked in successfully." : "✘ Failed.");
    }
 
    static void checkOut() {
        System.out.print("Shift ID for check-out: "); int shiftId = Integer.parseInt(sc.nextLine());
        System.out.println(attDAO.checkOut(currentUser.getEmpId(), shiftId) ?
                "✔ Checked out successfully." : "✘ Failed.");
    }

}
