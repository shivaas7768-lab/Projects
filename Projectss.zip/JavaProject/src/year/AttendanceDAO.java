package year;
import year.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AttendanceDAO {
    // ─── CREATE (Mark Attendance) ─────────────────────────────────────────────
    public boolean markAttendance(int empId, int shiftId) {
        String sql = "INSERT INTO attendance (emp_id, shift_id, check_in, status) VALUES (?, ?, NOW(), 'PRESENT')";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, empId);
            ps.setInt(2, shiftId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("markAttendance error: " + e.getMessage());
            return false;
        }
    }
 
    // ─── READ ALL with JOIN ───────────────────────────────────────────────────
    public List<String> getAttendanceReport() {
        List<String> report = new ArrayList<>();
        // JOIN QUERY: attendance with employee name, shift details, department
        String sql = "SELECT a.att_id, e.name AS emp_name, d.dept_name, " +
                     "       s.shift_date, s.shift_type, a.check_in, a.check_out, a.status " +
                     "FROM attendance a " +
                     "JOIN employees e  ON a.emp_id  = e.emp_id " +
                     "JOIN shifts s     ON a.shift_id = s.shift_id " +
                     "JOIN departments d ON e.dept_id = d.dept_id " +
                     "ORDER BY s.shift_date DESC";
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            report.add(String.format("%-5s %-18s %-14s %-12s %-12s %-22s %-22s %-10s",
                    "ID", "Employee", "Department", "Date", "Shift Type",
                    "Check In", "Check Out", "Status"));
            report.add("-".repeat(120));
            while (rs.next()) {
                report.add(String.format("%-5d %-18s %-14s %-12s %-12s %-22s %-22s %-10s",
                        rs.getInt("att_id"),
                        rs.getString("emp_name"),
                        rs.getString("dept_name"),
                        rs.getDate("shift_date"),
                        rs.getString("shift_type"),
                        rs.getTimestamp("check_in")  != null ? rs.getTimestamp("check_in").toString()  : "N/A",
                        rs.getTimestamp("check_out") != null ? rs.getTimestamp("check_out").toString() : "N/A",
                        rs.getString("status")));
            }
        } catch (SQLException e) {
            System.err.println("getAttendanceReport error: " + e.getMessage());
        }
        return report;
    }
 
    // ─── UPDATE (Check Out) ───────────────────────────────────────────────────
    public boolean checkOut(int empId, int shiftId) {
        String sql = "UPDATE attendance SET check_out = NOW() WHERE emp_id = ? AND shift_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, empId);
            ps.setInt(2, shiftId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("checkOut error: " + e.getMessage());
            return false;
        }
    }
 
    // ─── DELETE ───────────────────────────────────────────────────────────────
    public boolean deleteAttendance(int attId) {
        String sql = "DELETE FROM attendance WHERE att_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, attId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("deleteAttendance error: " + e.getMessage());
            return false;
        }
    }

}
