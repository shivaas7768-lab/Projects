package year;
import year.LeaveRequest;
import year.DBConnection;
 
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LeaveRequestDAO {

    // ─── CREATE ──────────────────────────────────────────────────────────────
    public boolean applyLeave(LeaveRequest lr) {
        String sql = "INSERT INTO leave_requests (emp_id, start_date, end_date, reason) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1,    lr.getEmpId());
            ps.setDate(2,   lr.getStartDate());
            ps.setDate(3,   lr.getEndDate());
            ps.setString(4, lr.getReason());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("applyLeave error: " + e.getMessage());
            return false;
        }
    }
 
    // ─── READ ALL ─────────────────────────────────────────────────────────────
    public List<LeaveRequest> getAllLeaveRequests() {
        List<LeaveRequest> list = new ArrayList<>();
        // JOIN QUERY: leave_requests with employee name
        String sql = "SELECT lr.leave_id, lr.emp_id, e.name AS emp_name, " +
                     "       lr.start_date, lr.end_date, lr.reason, lr.status, lr.applied_on " +
                     "FROM leave_requests lr " +
                     "JOIN employees e ON lr.emp_id = e.emp_id " +
                     "ORDER BY lr.applied_on DESC";
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                LeaveRequest lr = new LeaveRequest();
                lr.setLeaveId(rs.getInt("leave_id"));
                lr.setEmpId(rs.getInt("emp_id"));
                lr.setEmpName(rs.getString("emp_name"));
                lr.setStartDate(rs.getDate("start_date"));
                lr.setEndDate(rs.getDate("end_date"));
                lr.setReason(rs.getString("reason"));
                lr.setStatus(rs.getString("status"));
                lr.setAppliedOn(rs.getTimestamp("applied_on"));
                list.add(lr);
            }
        } catch (SQLException e) {
            System.err.println("getAllLeaveRequests error: " + e.getMessage());
        }
        return list;
    }
 
    // ─── READ BY EMPLOYEE ─────────────────────────────────────────────────────
    public List<LeaveRequest> getLeaveByEmployee(int empId) {
        List<LeaveRequest> list = new ArrayList<>();
        String sql = "SELECT lr.leave_id, lr.emp_id, e.name AS emp_name, " +
                     "       lr.start_date, lr.end_date, lr.reason, lr.status " +
                     "FROM leave_requests lr JOIN employees e ON lr.emp_id = e.emp_id " +
                     "WHERE lr.emp_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, empId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                LeaveRequest lr = new LeaveRequest();
                lr.setLeaveId(rs.getInt("leave_id"));
                lr.setEmpId(rs.getInt("emp_id"));
                lr.setEmpName(rs.getString("emp_name"));
                lr.setStartDate(rs.getDate("start_date"));
                lr.setEndDate(rs.getDate("end_date"));
                lr.setReason(rs.getString("reason"));
                lr.setStatus(rs.getString("status"));
                list.add(lr);
            }
        } catch (SQLException e) {
            System.err.println("getLeaveByEmployee error: " + e.getMessage());
        }
        return list;
    }
 
    // ─── UPDATE STATUS ────────────────────────────────────────────────────────
    public boolean updateLeaveStatus(int leaveId, String status) {
        String sql = "UPDATE leave_requests SET status = ? WHERE leave_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setInt(2,    leaveId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("updateLeaveStatus error: " + e.getMessage());
            return false;
        }
    }
 
    // ─── DELETE ───────────────────────────────────────────────────────────────
    public boolean deleteLeaveRequest(int leaveId) {
        String sql = "DELETE FROM leave_requests WHERE leave_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, leaveId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("deleteLeaveRequest error: " + e.getMessage());
            return false;
        }
    }

}
