package year;
import java.sql.Date;
import java.sql.Timestamp;
public class LeaveRequest {
    private int       leaveId;
    private int       empId;
    private String    empName;
    private Date      startDate;
    private Date      endDate;
    private String    reason;
    private String    status;
    private Timestamp appliedOn;
 
    public LeaveRequest() {}
 
    public LeaveRequest(int empId, Date startDate, Date endDate, String reason) {
        this.empId     = empId;
        this.startDate = startDate;
        this.endDate   = endDate;
        this.reason    = reason;
        this.status    = "PENDING";
    }
 
    public int       getLeaveId()  { return leaveId; }
    public void      setLeaveId(int leaveId) { this.leaveId = leaveId; }
    public int       getEmpId()    { return empId; }
    public void      setEmpId(int empId) { this.empId = empId; }
    public String    getEmpName()  { return empName; }
    public void      setEmpName(String empName) { this.empName = empName; }
    public Date      getStartDate(){ return startDate; }
    public void      setStartDate(Date startDate) { this.startDate = startDate; }
    public Date      getEndDate()  { return endDate; }
    public void      setEndDate(Date endDate) { this.endDate = endDate; }
    public String    getReason()   { return reason; }
    public void      setReason(String reason) { this.reason = reason; }
    public String    getStatus()   { return status; }
    public void      setStatus(String status) { this.status = status; }
    public Timestamp getAppliedOn(){ return appliedOn; }
    public void      setAppliedOn(Timestamp appliedOn) { this.appliedOn = appliedOn; }
 
    @Override
    public String toString() {
        return String.format("[%d] Employee: %-15s | %s to %s | Reason: %-20s | Status: %s",
                leaveId, empName != null ? empName : "ID:" + empId,
                startDate, endDate, reason, status);
    }


}
