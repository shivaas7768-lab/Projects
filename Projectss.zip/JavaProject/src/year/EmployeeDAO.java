package year;
import year.Employee;
import year.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDAO {
    // ─── CREATE ──────────────────────────────────────────────────────────────
    public boolean addEmployee(Employee emp) {
        String sql = "INSERT INTO employees (name, email, phone, role, dept_id, username, password) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, emp.getName());
            ps.setString(2, emp.getEmail());
            ps.setString(3, emp.getPhone());
            ps.setString(4, emp.getRole());
            ps.setInt(5,    emp.getDeptId());
            ps.setString(6, emp.getUsername());
            ps.setString(7, emp.getPassword());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("addEmployee error: " + e.getMessage());
            return false;
        }
    }
 
    // ─── READ ALL ─────────────────────────────────────────────────────────────
    public List<Employee> getAllEmployees() {
        List<Employee> list = new ArrayList<>();
        // JOIN QUERY 1: employees with department name
        String sql = "SELECT e.emp_id, e.name, e.email, e.phone, e.role, " +
                     "       e.dept_id, d.dept_name " +
                     "FROM employees e " +
                     "LEFT JOIN departments d ON e.dept_id = d.dept_id " +
                     "ORDER BY e.emp_id";
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                Employee emp = new Employee(
                    rs.getInt("emp_id"),
                    rs.getString("name"),
                    rs.getString("email"),
                    rs.getString("phone"),
                    rs.getString("role"),
                    rs.getInt("dept_id"),
                    rs.getString("dept_name")
                );
                list.add(emp);
            }
        } catch (SQLException e) {
            System.err.println("getAllEmployees error: " + e.getMessage());
        }
        return list;
    }
 
    // ─── READ BY ID ───────────────────────────────────────────────────────────
    public Employee getEmployeeById(int empId) {
        String sql = "SELECT e.emp_id, e.name, e.email, e.phone, e.role, " +
                     "       e.dept_id, d.dept_name " +
                     "FROM employees e LEFT JOIN departments d ON e.dept_id = d.dept_id " +
                     "WHERE e.emp_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, empId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Employee(
                    rs.getInt("emp_id"), rs.getString("name"), rs.getString("email"),
                    rs.getString("phone"), rs.getString("role"),
                    rs.getInt("dept_id"), rs.getString("dept_name")
                );
            }
        } catch (SQLException e) {
            System.err.println("getEmployeeById error: " + e.getMessage());
        }
        return null;
    }
 
    // ─── READ BY USERNAME & PASSWORD (Login) ──────────────────────────────────
    public Employee login(String username, String password) {
        String sql = "SELECT e.emp_id, e.name, e.email, e.phone, e.role, " +
                     "       e.dept_id, d.dept_name " +
                     "FROM employees e LEFT JOIN departments d ON e.dept_id = d.dept_id " +
                     "WHERE e.username = ? AND e.password = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Employee(
                    rs.getInt("emp_id"), rs.getString("name"), rs.getString("email"),
                    rs.getString("phone"), rs.getString("role"),
                    rs.getInt("dept_id"), rs.getString("dept_name")
                );
            }
        } catch (SQLException e) {
            System.err.println("login error: " + e.getMessage());
        }
        return null;
    }
 
    // ─── UPDATE ───────────────────────────────────────────────────────────────
    public boolean updateEmployee(Employee emp) {
        String sql = "UPDATE employees SET name=?, email=?, phone=?, role=?, dept_id=? WHERE emp_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, emp.getName());
            ps.setString(2, emp.getEmail());
            ps.setString(3, emp.getPhone());
            ps.setString(4, emp.getRole());
            ps.setInt(5,    emp.getDeptId());
            ps.setInt(6,    emp.getEmpId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("updateEmployee error: " + e.getMessage());
            return false;
        }
    }
 
    // ─── DELETE ───────────────────────────────────────────────────────────────
    public boolean deleteEmployee(int empId) {
        String sql = "DELETE FROM employees WHERE emp_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, empId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("deleteEmployee error: " + e.getMessage());
            return false;
        }
    }

}
